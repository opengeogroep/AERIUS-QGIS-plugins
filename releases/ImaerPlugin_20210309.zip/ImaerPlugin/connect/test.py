from aerius_connection import AeriusConnection

ac = AeriusConnection()
print(ac)
