from enum import Enum


class OutflowDirectionType(Enum):
    VERTICAL = 1
    HORIZONTAL = 2
