from .main import FeatureCollectionCalculator
from .main import AeriusCalculatorMetadata
from .main import EmissionSource
from .gml import GmlWriter
from .es_characteristics import EmissionSourceCharacteristics, SpecifiedHeatContent, CalculatedHeatContent, Building

# constants (todo: make these work)
'''
_gml_ns = 'http://www.opengis.net/gml/3.2'
_imaer_ns = 'http://imaer.aerius.nl/3.1'
_imaer_schema_location = 'http://imaer.aerius.nl/3.1/IMAER.xsd'
_gml_id = 'NL.IMAER.Collection'
'''
